from django.shortcuts import render

# Create your views here.
def main(request):
    return render(request, 'main.html')

def nav(request):
    return render(request, 'navbar.html')

def contact(request):
    return render(request, 'contact.html')