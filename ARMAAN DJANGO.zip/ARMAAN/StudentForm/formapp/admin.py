from django.contrib import admin
from .models import Student
from django.contrib.auth.admin import UserAdmin
# Register your models here.

class StudentAdmin(admin.ModelAdmin):
    list_filter = ['first_name']
    search_fields = ['first_name']
    list_display = ('first_name')
admin.site.register(Student)
