from django.shortcuts import render
from django.contrib import messages
from .forms import StudentForm
# Create your views here.

def form(request):
    form = StudentForm()
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "FORM SUBMITTED")
        else:
            form = StudentForm()
    return render(request, 'form.html', {'form': form}) 

