from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
# Create your models here.

class SignUp(models.Model):
    acc_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=20)
    last_name = models.CharField(max_length=20)
    username = models.CharField(max_length=11)
    email = models.CharField(max_length=20)
    age = models.IntegerField( validators = [
        MinValueValidator(1),
        MaxValueValidator(12),
    ])
    password = models.IntegerField()
    password1 = models.IntegerField()

class Login(models.Model):
    username = models.CharField(max_length=11)
    password = models.IntegerField()
