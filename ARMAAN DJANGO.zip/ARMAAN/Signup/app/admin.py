from django.contrib import admin
from .models import SignUp, Login
admin.site.register(SignUp)
admin.site.register(Login)

# Register your models here.
