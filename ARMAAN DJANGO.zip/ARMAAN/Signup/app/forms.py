from django import forms
from .models import SignUp, Login

class SignUpForm(forms.ModelForm):
    class Meta:
        model = SignUp
        fields = ['first_name', 'last_name', 'email', 'username', 'age', 'password', 'password1']

class LoginForm(forms.ModelForm):
    class Meta:
        model = Login
        fields = ['username', 'password']