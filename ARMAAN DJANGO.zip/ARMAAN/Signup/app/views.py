from django.shortcuts import render, redirect # type: ignore
from .forms import SignUpForm, LoginForm
from .models import SignUp
from django.contrib.auth.hashers import check_password


# Create your views here.
def Signup(request):
    if request.method=="POST":
        form = SignUpForm(request.POST)
        if form.is_valid(): 
           password = form.cleaned_data.get('password')
           password1 = form.cleaned_data.get('password1')
           username = form.cleaned_data.get('username')
           alldata = SignUp.objects.all()

           if (password != password1):
               return render (request, 'failed.html')
           if alldata.filter(username=username).exists():
                return render(request, 'failed.html')
        form.save()
        return redirect(request, 'success.html')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {"form":form})
           
               
def index(request):
    return render(request, 'index.html')          


def login(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            
            try:
                user = SignUp.objects.get(username=username)
            
                if password == user.password:
                    return render(request, 'sucess.html')
                else:
                    return render(request, 'failed.html')
            except SignUp.DoesNotExist:
                return render(request, 'failed.html')
    else:
        form = LoginForm()

    return render(request, 'login.html', {"form": form})
       