from django.db import models
from django.utils import timezone
# Create your models here.

class Emp(models.Model):
    emp_id = models.AutoField(primary_key=True)
    emp_name = models.CharField(max_length=50)
    emp_lname = models.CharField(max_length=50)
    emp_salary = models.IntegerField()

class Contact(models.Model):
    subject = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    pno = models.CharField(max_length=15)  # Phone number
    message = models.TextField()
    

    def __str__(self):
        return self.subject


    



