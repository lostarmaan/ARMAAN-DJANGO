from django.apps import AppConfig


class ArmaanAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'armaan_app'
