from django.shortcuts import render, redirect
from .models import Emp
from django.shortcuts import render
from django.http import HttpResponse
from .forms import ContactForm


# Create your views here.

def index(request):
    emps = Emp.objects.all()
    return render(request, 'index.html', {'Emp': emps})

def contact(request):
    return render(request, 'contact.html')

# views.py


# views.py


def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()  # Save data to the database
            return redirect('success')  # Redirect to a success page
    else:
        form = ContactForm()

    return render(request, 'contact.html', {'form': form})


#signup view

