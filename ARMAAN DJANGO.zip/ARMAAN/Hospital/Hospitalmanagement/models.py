from django.db import models
class Service(models.Model):
    icon=models.CharField(max_length=50)
    title=models.CharField(max_length=50)
    des=models.TextField()
# Create your models here.
