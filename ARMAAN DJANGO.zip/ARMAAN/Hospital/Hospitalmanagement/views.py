from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.


def sumit(request):
    return HttpResponse("<b>Welcomr to Aptech Learing Hathi Gate</b>")


def index(request): 
    data={
        'title':'Home Page',
        'bdata':'Aptech Learning',
        'clist':['PHP','JAVA','DJANGO'],
        'number':[10,20,30,40,50],
        'sdetails':[
            {'name':'sumit','Phone':7894561230},
            {'name':'Aman','Phone':9874561230},
            {'name':'Kartik','Phone':9632587410}
        ]
    }
    return render(request,'templates/index.html',data)

def kakudetails(request,courseid):
    return HttpResponse(courseid)

def contact(request):
        return render(request,'templates/contact.html')

def chatbot(request):
     return render(request,'templates/javascript.html')

def port(request):
     return render(request,'templates/port.html')

