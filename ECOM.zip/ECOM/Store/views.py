from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from .forms import SignupForm
from .models import Product, Category 



# NAVIGATION PAGES #
def index(request):
    products = Product.objects.all()
    category = Category.objects.all()

    grouped_products = {}
    for cat in category:
        # Get all products in this category
        category_products = products.filter(category=category)
        grouped_products[cat] = category_products

    context = {
        "grouped_products":grouped_products,
        "category":category
    }
    return render(request, 'index.html', context)

def tracker(request):
    return render(request, 'tracker.html')

def orders(request):
    return render(request, 'orders.html')

def contact(request):
    return render(request, 'contact.html')

def about(request):
    return render(request, 'about.html')



# NAVIGATION BUTTONS #
def signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)  # Use the custom SignUpForm (inherits UserCreationForm)
        if form.is_valid():
            # The user is created automatically by the form
            form.save()

            # Optionally, log in the user after successful creation
            login(request, user)

            # Show a success message
            messages.success(request, "You have successfully signed up!")

            # Redirect to a page (for example, the home page)
            return redirect('index')  # Replace 'home' with your desired page

        else:
            # If form is invalid, return it to the template with errors
            messages.error(request, "There were errors in the form. Please check your inputs.")
    else:
        form = SignupForm()  # Render the form for GET requests

    return render(request, 'signup.html', {'form': form})

def login(request):
    return render(request, 'login.html')

def cart(request):
    return render(request, 'cart.html')

