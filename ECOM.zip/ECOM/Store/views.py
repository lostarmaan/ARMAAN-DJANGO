from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from .forms import SignupForm, ContactForm
from .models import Product, Category, Cart, CartItem




# NAVIGATION PAGES #
def index(request):

    products = Product.objects.all()
    category = Category.objects.all()

    context = {
        "product": products,
        "category": category
    }

    if request.method == "POST" and "logout" in request.POST:
        logout(request)
        return redirect('index')
    
    if request.user.is_authenticated:
        if request.method == "POST" and "additem" in request.POST:
        
            product_id = request.POST.get('id')
            product_quantity = request.POST.get('quantity')
            product_quantity = int(product_quantity)
            product = Product.objects.get(id=product_id)

            cart= Cart.objects.get(user=request.user)
            cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)

            if not created:
                cart_item.quantity += product_quantity
            else:
                cart_item.quantity = product_quantity

            cart_item.save()

    return render(request, 'index.html', context)



def tracker(request):
    return render(request, 'tracker.html')

def orders(request):
    return render(request, 'orders.html')

def contact(request):
    form = ContactForm()
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            contact = form.save(commit=False)
            contact.user = request.user
            contact.save()
            messages.success(request, "Message Has Been Sent")
    else:
        form = ContactForm()
    return render(request, 'contact.html', {"form": form})

def about(request):
    return render(request, 'about.html')



# NAVIGATION BUTTONS #


def profile(request):
    return render(request, 'profile.html')
def signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)  # Use the custom SignUpForm (inherits UserCreationForm)
        if form.is_valid():
            # Save the form and create the user
            form.save()
            messages.success(request, "You have successfully signed up!")
        else:
            # If form is invalid, return it to the template with error messages
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")

    else:
        form = SignupForm()  # Render the form for GET requests

    return render(request, 'signup.html', {'form': form})

def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Authenticate the user
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            # Log the user in
            login(request, user)  # Using the renamed login function here
            messages.success(request, "You have successfully logged in!")
            Cart.objects.get_or_create(user=request.user)
            
        else:
            # Invalid login credentials
            messages.error(request, "Invalid login credentials")


    return render(request, 'login.html')


def cart_view(request): 
    cart = Cart.objects.get(user = request.user)

    cart_items = CartItem.objects.filter(cart=cart)

    total_quantity = sum(item.quantity for item in cart_items)
    total_price = sum(item.quantity * item.product.price for item in cart_items)

    context = {
        'cart_items': cart_items,
        'total_quantity': total_quantity,
        'total_price': total_price,
     
    }

    return render(request, 'cart.html', context)

