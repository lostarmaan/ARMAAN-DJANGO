from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from .forms import SignupForm
from .models import Product, Category 



# NAVIGATION PAGES #
def index(request):

    products = Product.objects.all()
    category = Category.objects.all()

    context = {
        "product": products,
        "category": category
    }

    if request.method == "POST" and "logout" in request.POST:
        logout(request)
    return render(request, 'index.html', context)



def tracker(request):
    return render(request, 'tracker.html')

def orders(request):
    return render(request, 'orders.html')

def contact(request):
    return render(request, 'contact.html')

def about(request):
    return render(request, 'about.html')



# NAVIGATION BUTTONS #


def profile(request):
    return render(request, 'profile.html')
def signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)  # Use the custom SignUpForm (inherits UserCreationForm)
        if form.is_valid():
            # Save the form and create the user
            form.save()
            messages.success(request, "You have successfully signed up!")
        else:
            # If form is invalid, return it to the template with error messages
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")

    else:
        form = SignupForm()  # Render the form for GET requests

    return render(request, 'signup.html', {'form': form})

def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Authenticate the user
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            # Log the user in
            login(request, user)  # Using the renamed login function here
            messages.success(request, "You have successfully logged in!")
        else:
            # Invalid login credentials
            messages.error(request, "Invalid login credentials")

    return render(request, 'login.html')


def cart(request):
    return render(request, 'cart.html')

