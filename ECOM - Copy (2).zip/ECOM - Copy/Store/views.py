from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from .forms import SignupForm, ContactForm, ProfileForm
from .models import Product, Category, Cart, CartItem, Profile, Order
from django.db.models import Q




# NAVIGATION PAGES #

def nav(request):
    category = Category.objects.all()
    return render(request, 'nav.html', {"category": category})
from django.db.models import Q  # Make sure to import Q for complex queries

def index(request):
    # Get all products and categories
    products = Product.objects.all()
    category = Category.objects.all()

    # LOGOUT FROM ACCOUNT 
    if request.method == "POST" and "logout" in request.POST:
        logout(request)
        return redirect('index')

    # ADD PRODUCT TO CART 
    if request.user.is_authenticated:
        if request.method == "POST" and "additem" in request.POST:
            product_id = request.POST.get('id')
            product_quantity = request.POST.get('quantity')
            product_quantity = int(product_quantity)
            product = Product.objects.get(id=product_id)

            cart = Cart.objects.get(user=request.user)
            cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)

            if not created:
                cart_item.quantity += product_quantity
            else:
                cart_item.quantity = product_quantity

            cart_item.save()
    context = {
        "product": products,  # Show only searched products or all products if no search
        "category": category,
    }

    return render(request, 'index.html', context)


def searched(request):
    
    if request.method == "POST" and "search" in request.POST:
        search = request.POST.get("search", "").strip()

        if search:
            # Search for products where the search term matches name, description, category, or subcategory
            searched_products = Product.objects.filter(
                Q(name__icontains=search) |  # Search in product name
                Q(desc__icontains=search) |  # Search in product description
                Q(category__name__icontains=search) |  # Search in category name
                Q(subcategory__icontains=search)  # Search in subcategory name
            )
            return redirect(request, "searched")
    # Prepare context for rendering the template
    context = {
        "product": searched_products,  # Show only searched products or all products if no search
    }
    

    return render(request, 'searched.html', context)

def orders(request):
    # Filter orders for the logged-in user
    orders = Order.objects.filter(user=request.user)
    
    # Separate orders by their status
    placed_orders = orders.filter(status="Pending")  # For "Placed" orders
    delivered_orders = orders.filter(status="Delivered")  # For "Delivered" orders
    cancelled_orders = orders.filter(status="Cancelled")  # For "Cancelled" orders

    # Pass the grouped orders to the template
    return render(request, 'orders.html', {
        'placed_orders': placed_orders,
        'delivered_orders': delivered_orders,
        'cancelled_orders': cancelled_orders
    })

def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            contact = form.save(commit=False)  
            contact.user = request.user 
            contact.save()  
            messages.success(request, "Message has been sent")
        else:
            messages.error(request, "Something Is Wrong! Message Has Not Been Sent")
    else:
        form = ContactForm()

    return render(request, 'contact.html', {'form': form})

def about(request):
    return render(request, 'about.html')



# NAVIGATION BUTTONS #


def profile(request):
    # Try to get the user's profile, or create it if it doesn't exist
    profile, created = Profile.objects.get_or_create(user=request.user)

    # Handle form submission (editing the profile)
    if request.method == "POST":
        form = ProfileForm(request.POST, request.FILES, instance=profile)  # Pass the existing profile instance
        if form.is_valid():
            form.save()  # Save the updated profile
            messages.success(request, "Your profile has been updated successfully!")
            return redirect('profile')  # Redirect after successful save
        else:
            messages.error(request, "There were problems saving the form.")
    else:
        form = ProfileForm(instance=profile)  # Prepopulate the form with the current profile data

    return render(request, 'profile.html', {
        "profile": profile,
        "form": form
    })

def signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)  # Use the custom SignUpForm (inherits UserCreationForm)
        if form.is_valid():
            # Save the form and create the user
            form.save()
            messages.success(request, "You have successfully signed up!")
        else:
            # If form is invalid, return it to the template with error messages
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")

    else:
        form = SignupForm()  # Render the form for GET requests

    return render(request, 'signup.html', {'form': form})

def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Authenticate the user
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            # Log the user in
            login(request, user)  # Using the renamed login function here
            messages.success(request, "You have successfully logged in!")
            Cart.objects.get_or_create(user=request.user)
            Profile.objects.get_or_create(user=request.user)
        else:
            # Invalid login credentials
            messages.error(request, "Invalid login credentials")
    return render(request, 'login.html')

@login_required
def cart_view(request):
    cart = Cart.objects.get(user=request.user)
    cart_items = CartItem.objects.filter(cart=cart)
    total_quantity = sum(item.quantity for item in cart_items)
    total_price = sum(item.quantity * item.product.price for item in cart_items)
    

    # CHAGING QUANTITY IN THE CAR
    if request.method == "POST" and "refresh" in request.POST:
        product_id = request.POST.get('id')
        product_quantity = request.POST.get('quantity')
        
        if product_quantity:
            product_quantity = int(product_quantity) 
        else:
            return redirect('cart_view') 

        try:
            product = Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return redirect('cart_view')  
        
        cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)

        if not created:
            cart_item.quantity = product_quantity
        else:
            cart_item.quantity = product_quantity

        cart_item.save() 
        return redirect('cart_view')
    
    # DELETING THE ITEM FROM CART
    if request.method == "POST" and "delete" in request.POST:
        product_id = request.POST.get('id')
        cart = Cart.objects.get(user=request.user)
        product = Product.objects.get(id=product_id)

        cart_item = CartItem.objects.filter(cart=cart, product=product)
        cart_item.delete()

    # PLACING ORDER AND DELETING CART ITEMS
    if request.method == "POST" and "checkout" in request.POST:

        cart = Cart.objects.get(user=request.user)
        cart_items = CartItem.objects.filter(cart=cart)
        total_quantity = sum(item.quantity for item in cart_items)
        total_price = sum(item.quantity * item.product.price for item in cart_items)
        profile = Profile.objects.get(user=request.user)
        shipping_address = profile.add 
    
        
        if not shipping_address:
            return messages.error(request, "Shipping address is required.")
        
        if not cart_items:
            return messages.error(request, "Cart is empty or all items have already been ordered")
        
        # Create the Order
        order = Order.objects.create(
            user=request.user,
            total_price=total_price,
            shipping_address=shipping_address
        )
        
        order.order_items.set(cart_items)
        return redirect("orders")
 
        

    return render(request, 'cart.html', {
        'cart_items': cart_items,
        'total_quantity': total_quantity,
        'total_price': total_price
    })

