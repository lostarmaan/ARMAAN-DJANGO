from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
# Create your models here.


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete = models.CASCADE)
    pfp = models.ImageField(upload_to="static/profile_img", default = "static/profile_img/default123.jpg")
    bio = models.CharField(max_length=75, null = True)
    dob = models.DateField(null=True)
    add1 = models.CharField(max_length=50,  blank=True, null=True)
    add2 = models.CharField(max_length=50,  blank=True, null=True)


class Category(models.Model):
    category = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.category
class Product(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=25)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='products')
    subcategory = models.CharField(max_length=50, default="")
    price = models.IntegerField(default=0)
    desc = models.CharField(max_length=150)
    pub_date = models.DateField()
    image = models.ImageField(upload_to="static/prod_img/", default="")

    def __str__(self):
        return self.name


class Cart(models.Model):
    user = models.ForeignKey(User, on_delete = models.CASCADE)
    
    def __str__(self):
        return f"Cart for {self.user.username}"
    
class CartItem(models.Model):
    cart = models.ForeignKey(Cart, related_name = "items", on_delete = models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    added_at = models.DateTimeField(auto_now_add=True)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return self.cart.user.username

class Contact(models.Model):
    msg_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete = models.CASCADE, default="")
    subject = models.CharField(max_length=15 ,default="")
    name = models.CharField(max_length=20 ,default="")
    email = models.CharField(max_length=25, default="")
    phone = models.CharField(max_length=10, default="")
    message = models.TextField( default="")
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"user: {self.user.username} subject: {self.subject}"


