from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from .models import Contact, Profile



class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['pfp', 'bio', 'dob', 'add1', 'add2']

 
        def __init__(self,  *args, **kwargs):
            super().__init__(*args, **kwargs)

            for field in self.fields.values():
                field.label = ""  # Remove the label
                field.help_text = None  # Remove the help text (explanation)  
    dob = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    pfp = forms.ImageField(widget=forms.ClearableFileInput(attrs={'multiple': False}))


class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = ['subject', 'name', 'email', 'phone', 'message']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        self.fields['subject'].widget.attrs['placeholder'] = "Subject"
        self.fields['name'].widget.attrs['placeholder'] = "Your Full Name"
        self.fields['email'].widget.attrs['placeholder'] = " Your Email"
        self.fields['phone'].widget.attrs['placeholder'] = "Your Contact Number"
        self.fields['message'].widget.attrs['placeholder'] = "Your Message"

        for field in self.fields.values():
            field.label = ""  # Optionally, remove the label

class SignupForm(UserCreationForm):
    email = forms.EmailField(max_length=100)
    first_name = forms.CharField(max_length=50)
    last_name = forms.CharField(max_length=50)

    class Meta:
        model = User
        fields = [ 'first_name', 'last_name', 'username', 'email', 'password1', 'password2']
    def __init__(self,  *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['first_name'].widget.attrs['placeholder'] = "First Name"
        self.fields['last_name'].widget.attrs['placeholder'] = "Last Name"
        self.fields['username'].widget.attrs['placeholder'] = "Username"
        self.fields['email'].widget.attrs['placeholder'] = "Email"
        self.fields['password1'].widget.attrs['placeholder'] = "Password"
        self.fields['password2'].widget.attrs['placeholder'] = "Confirm Password"

        
        for field in self.fields.values():
            field.label = ""  # Remove the label
            field.help_text = None  # Remove the help text (explanation)          
            
            
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise ValidationError('Username already exists.')
        return username

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise ValidationError('Email is already in use.')
        return email

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get("password1")
        password2 = cleaned_data.get("password2")

        # Custom validation for password match
        if password1 and password2:
            if password1 != password2:
                raise ValidationError("Passwords do not match.")
        
        return cleaned_data
    

